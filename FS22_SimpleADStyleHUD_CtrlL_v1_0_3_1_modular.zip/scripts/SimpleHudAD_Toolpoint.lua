-- FS22 Survey HUD - Toolpoint / kinematics library
-- v1.0.3.1
-- Note: Functions are intentionally not wired into gameplay yet (modular future use).

SimpleHudAD.toolpoint = SimpleHudAD.toolpoint or {}

-- Placeholder for future kinematics: keep API stable for modular use later.
function SimpleHudAD.toolpoint:getToolpointNode(vehicle)
    return nil
end

function SimpleHudAD.toolpoint:getToolpointWorldPosition(vehicle)
    return nil
end
